def restar(n1,n2):
    print("El resultado de la resta es:", n1-n2)
    