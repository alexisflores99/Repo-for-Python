def suma(n1,n2):
    print("El resultado de la suma es: ",n1+n2)
    