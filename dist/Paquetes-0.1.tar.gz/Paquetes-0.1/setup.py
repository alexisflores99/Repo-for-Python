from setuptools import setup

setup(
    name = "Paquetes",
    version = "0.1",
    descripcion = "Mi primer paquete",
    author = "Alexis Flores",
    authorEmail = "alexis@alexis.com",
    url = "",
    scripts = [],
    packages = ["Paquetes","Paquetes.op1", "Paquetes.op2" ]
)